CREATE TABLE IF NOT EXISTS users (
 id BIGSERIAL PRIMARY KEY, telegram_id BIGINT UNIQUE NOT NULL,
 username VARCHAR(128), first_name VARCHAR(128),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), is_blocked BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE TABLE IF NOT EXISTS wallet_transactions (
 id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id),
 transaction_ref VARCHAR(80) UNIQUE NOT NULL, transaction_type VARCHAR(32) NOT NULL,
 amount_paisa BIGINT NOT NULL CHECK(amount_paisa >= 0),
 status VARCHAR(24) NOT NULL DEFAULT 'pending', description TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS task_submissions (
 id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id),
 task_code VARCHAR(80) NOT NULL, proof_text TEXT,
 status VARCHAR(24) NOT NULL DEFAULT 'pending', reviewed_by BIGINT,
 reviewed_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS withdrawal_requests (
 id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id),
 amount_paisa BIGINT NOT NULL CHECK(amount_paisa >= 5000),
 payment_method VARCHAR(20) NOT NULL, account_number VARCHAR(40) NOT NULL,
 status VARCHAR(24) NOT NULL DEFAULT 'pending', payment_reference VARCHAR(100),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), reviewed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS referrals (
 id BIGSERIAL PRIMARY KEY, referrer_user_id BIGINT NOT NULL REFERENCES users(id),
 referred_user_id BIGINT UNIQUE NOT NULL REFERENCES users(id),
 qualified_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_wallet_user_created ON wallet_transactions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_task_status ON task_submissions(status);
CREATE INDEX IF NOT EXISTS idx_withdrawal_status ON withdrawal_requests(status);
