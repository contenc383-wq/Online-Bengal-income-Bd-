from fastapi.testclient import TestClient
from backend.app.main import app
client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_features_has_fifty_items():
    response = client.get("/features")
    assert response.status_code == 200
    assert len(response.json()["features"]) == 50
