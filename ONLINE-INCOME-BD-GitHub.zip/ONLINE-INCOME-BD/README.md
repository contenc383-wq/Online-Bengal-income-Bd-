# ONLINE INCOME BD

বাংলাদেশি ব্যবহারকারীদের জন্য Telegram Bot + Mini App ভিত্তিক প্ল্যাটফর্মের GitHub-ready starter project।

## দুটি Bot আলাদা রাখুন
- **BOT 01 — Main Bot:** `@onlineearnhub_bot` — ব্যবহারকারী ও Mini App-এর মূল Bot।
- **BOT 02 — Notification Bot:** `@notifyllysae_bot` — অ্যাডমিন নোটিফিকেশনের Bot।

Token আলাদা environment variable-এ থাকবে: `MAIN_BOT_TOKEN` এবং `NOTIFICATION_BOT_TOKEN`। কোনো token GitHub-এ commit করবেন না।

## অন্তর্ভুক্ত
- FastAPI API starter, Telegram initData signature verification helper
- PostgreSQL-ready SQL schema
- Bengali responsive Mini App dashboard
- ৫০টি feature tile; এখনো চালু না হওয়া ফিচারগুলো Coming Soon
- BOT 01 ও BOT 02-এর পৃথক config
- Render blueprint, tests, `.env.example`

## গুরুত্বপূর্ণ
এটি **starter/MVP foundation**, সম্পূর্ণ earning platform নয়। Ad network verification, payment provider integration, task review workflow, quiz admin, referral qualification, পূর্ণ admin dashboard এবং production fraud controls এখনো সংযুক্ত নয়। এগুলো তৈরি ও পরীক্ষা না হওয়া পর্যন্ত কোনো আয় বা payment কার্যকর বলে দেখানো হবে না।

## Structure
```text
ONLINE-INCOME-BD/
├── backend/app/
│   ├── api/routes.py
│   ├── config.py
│   ├── database.py
│   ├── main.py
│   ├── security.py
│   └── notifications.py
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
├── database/schema.sql
├── tests/test_health.py
├── .env.example
├── .gitignore
├── requirements.txt
├── render.yaml
└── README.md
```

## Environment variables
`.env.example` কপি করে `.env` তৈরি করুন। `.env` GitHub-এ দেবেন না।
- `DATABASE_URL`
- `MAIN_BOT_TOKEN` — BOT 01
- `NOTIFICATION_BOT_TOKEN` — BOT 02
- `ADMIN_TELEGRAM_ID`
- `WEBAPP_URL`

## Local API check
Python 3.11+:
```bash
pip install -r requirements.txt
uvicorn backend.app.main:app --reload
```
তারপর `/health` endpoint পরীক্ষা করুন। `DATABASE_URL` না দিলে local SQLite fallback হবে।

## Security
Telegram initData server-side verify করতে হবে। Reward, balance, referral qualification ও withdrawal server-side হিসাব করতে হবে। Withdrawal-কে payment পাঠানোর আগে paid হিসেবে mark করবেন না। BOT 02-তে admin notification পেতে admin account থেকে ওই Bot-এ `/start` করা থাকতে হবে।
