from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel, Field
from backend.app.security import verify_telegram_init_data
from backend.app.notifications import notify_admin_bot02

router = APIRouter()
NAMES = [
"দৈনিক লগইন বোনাস","বিজ্ঞাপন দেখুন","ভিডিও টাস্ক","টাইপিং কাজ","ডাটা এন্ট্রি","কুইজ খেলুন","ছোট ছোট কাজ","দৈনিক চ্যালেঞ্জ","দক্ষতা যাচাই","সহজ কাজ",
"ফেসবুক টাস্ক","ইনস্টাগ্রাম টাস্ক","ইউটিউব টাস্ক","টিকটক টাস্ক","টেলিগ্রাম টাস্ক","সোশ্যাল শেয়ার","কনটেন্ট এনগেজমেন্ট","চ্যানেল টাস্ক","কমিউনিটি টাস্ক","সোশ্যাল ক্যাম্পেইন",
"সার্ভে","অ্যাপ টেস্টিং","ওয়েবসাইট টেস্টিং","লেখালেখির কাজ","ছবির কাজ","ডিজিটাল মার্কেটিং","মাইক্রো জব","ইমেইল ম্যানেজমেন্ট","অনলাইন রিসার্চ","বিশেষ ক্যাম্পেইন",
"রেফারেল লিংক","রেফারেল আয়","রেফারেল ইতিহাস","দৈনিক লক্ষ্য","সাপ্তাহিক লক্ষ্য","মাসিক লক্ষ্য","টিম লক্ষ্য","লিডারবোর্ড","পুরস্কার","ভিআইপি সুবিধা",
"ডিজিটাল সার্ভিস","ডিজিটাল পণ্য","মোবাইল রিচার্জ","গিফট কার্ড","মার্কেটপ্লেস","ওয়ালেট","টাকা উত্তোলন","লেনদেনের ইতিহাস","প্রোফাইল","সাপোর্ট"
]
FEATURES = [{"id": i, "title": name, "status": "coming_soon"} for i, name in enumerate(NAMES, 1)]

@router.get("/health")
async def health():
    return {"status": "ok", "project": "ONLINE INCOME BD"}

@router.get("/features")
async def get_features():
    return {"features": FEATURES}

@router.get("/me")
async def get_me(telegram_init_data: str = Header(default="", alias="X-Telegram-Init-Data")):
    if not telegram_init_data:
        raise HTTPException(status_code=401, detail="Telegram Mini App authentication required")
    try:
        data = verify_telegram_init_data(telegram_init_data)
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=401, detail=str(exc))
    return {"authenticated": True, "user": data.get("user", {})}

class AlertRequest(BaseModel):
    message: str = Field(min_length=1, max_length=1000)

@router.post("/internal/test-notification")
async def test_notification(payload: AlertRequest):
    # Development smoke-test endpoint; protect or remove before production.
    sent = await notify_admin_bot02("[ONLINE INCOME BD TEST]\\n" + payload.message)
    return {"sent": sent, "bot": "BOT 02 — Notification Bot"}
