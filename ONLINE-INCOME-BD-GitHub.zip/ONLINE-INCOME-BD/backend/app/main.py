from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.app.config import settings
from backend.app.api.routes import router

app = FastAPI(title=settings.app_name, version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if settings.environment == "development" else [],
    allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["*"]
)
app.include_router(router)

@app.get("/")
async def root():
    return {"message": "ONLINE INCOME BD API is running", "docs": "/docs"}
