import httpx
from backend.app.config import settings

async def notify_admin_bot02(message: str) -> bool:
    # Admin notification is sent by BOT 02 only; admin must have started that bot.
    token = settings.notification_bot_token
    admin_id = settings.admin_telegram_id
    if not token or not admin_id:
        return False
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    async with httpx.AsyncClient(timeout=10) as client:
        response = await client.post(url, json={
            "chat_id": admin_id, "text": message, "disable_web_page_preview": True
        })
        response.raise_for_status()
        return bool(response.json().get("ok"))
