import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl
from backend.app.config import settings

def verify_telegram_init_data(init_data: str, max_age_seconds: int = 86400) -> dict:
    # Verify Telegram Mini App initData; never trust a browser-supplied user ID.
    token = settings.main_bot_token
    if not token:
        raise ValueError("BOT 01 token is not configured")
    values = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = values.pop("hash", None)
    if not received_hash:
        raise ValueError("Missing Telegram hash")
    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(values.items()))
    secret_key = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, received_hash):
        raise ValueError("Invalid Telegram signature")
    auth_date = int(values.get("auth_date", "0"))
    if not auth_date or abs(time.time() - auth_date) > max_age_seconds:
        raise ValueError("Telegram initData expired")
    if "user" in values:
        values["user"] = json.loads(values["user"])
    return values
