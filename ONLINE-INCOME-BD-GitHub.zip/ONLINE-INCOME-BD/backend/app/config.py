from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "ONLINE INCOME BD"
    environment: str = "development"
    database_url: str = "sqlite+aiosqlite:///./online_income_bd.db"
    main_bot_token: str = ""
    notification_bot_token: str = ""
    bot01_username: str = "onlineearnhub_bot"
    bot02_username: str = "notifyllysae_bot"
    admin_telegram_id: str = "8628855492"
    webapp_url: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

settings = Settings()
